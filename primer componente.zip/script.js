import React from 'https://esm.sh/react@18.2.0'
import ReactDom from 'https://esm.sh/react-dom@18.2.0/client'

// tomamos el id app, donde vamos a colocar el componente react
const appDomElement = document.getElementById('app')

// cremos el arbol de elementos de react
const root = ReactDom.createRoot(appDomElement)

const button1 = React.createElement('button', {"data-id":123}, 'Buton1')
const button2 = React.createElement('button', {"data-id":456}, 'Buton2')
const button3 = React.createElement('button', {"data-id":789}, 'Buton3')

// creamos una constante, para agrupar todo lo que queremos incluir en el render
const div = React.createElement(React.Fragment, null, [button1, button2, button3])


// Hacemos el render, dentro de elemento div que hemos creado para incluir todo
root.render(div)


/* JSX esto de aquí es lo mismo que lo de arriba
<React.Fragment>
  <button data-id="123">Button1</button>
  <button data-id="123">Button2</button>
  <button data-id="123">Button3</button>
</React.Fragment>
*/

