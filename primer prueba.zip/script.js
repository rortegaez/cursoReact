//recuperarmos el botón

const buton = document.querySelector('button')

//al hacer click en el botón, tenemos que ejecutar una función

/* Un ejemplo de como comprobar si funciona el addEventListener
 buton.addEventListener('click', function() {
  alert('hola') 
}) */ 
buton.addEventListener('click', function() {
  //recuperamos la ide del atributo de HTML
  const id = buton.getAttribute('data-id')
  
  if(buton.classList.contains('liked')){
    buton.classList.remove('liked')
    buton.innerText = "Me gusta"
  } else {
    buton.classList.add('liked')
    buton.innerText = "Quitar me gusta"
  }
})